rm(list=ls())

getwd()
library(dplyr)

plant <- read.csv("D:/IC Silwood/Project/R/plant_OTU_sample_taxonomy.csv")
plant <- plant %>%
  filter(kingdom != "Fungi" & kingdom != "Bacteria")

plant <- plant %>%
  select(OTU, 26:243) 
rownames(plant)<-plant$OTU
plant$OTU<-NULL
plant<-t(plant)
plant<-as.data.frame(plant)
plant <- plant %>%
  mutate(across(where(is.numeric), ~ ifelse(. > 0, 1, 0)))
plant<-as.matrix(plant)

insect <- read.csv("D:/IC Silwood/Project/R/6-Insects_OTUs_Huatulco_Chamela_complete.csv")
insect <- insect %>%
  filter(Family != "Mantodea" & Family != "Odonata") %>%
  select(OTU, 12:230)  
rownames(insect)<-insect$OTU
insect$OTU<-NULL
insect<-t(insect)

library(vegan)
insect_dist <- vegdist(insect, method = "bray")
plant_dist <- vegdist(plant, method = "bray")
mantel_result <- mantel(insect_dist, plant_dist)
print(mantel_result)

library(ggplot2)
insect_dist_vector <- as.vector(as.dist(insect_dist))
plant_dist_vector <- as.vector(as.dist(plant_dist))

mantel_plot_data <- data.frame(
  insect_dist = insect_dist_vector,
  plant_dist = plant_dist_vector
)

ggplot(mantel_plot_data, aes(x = plant_dist, y = insect_dist)) +
  geom_point(color = "#1f78b4", alpha = 0.1) +
  geom_smooth(method = "lm", color = "#e31a1c", se = FALSE) + 
  theme_classic() +
  labs(x = "Plant Community Dissimilarity",
       y = "Insect Community Dissimilarity",
       title = paste("Mantel Test: r =", round(mantel_result$statistic, 4), 
                     ", p =", mantel_result$signif)) +
  annotate("text", x = 0.8, y = 0.2, label = paste("r =", round(mantel_result$statistic, 4)), 
           size = 6, color = "black")

environment<-read.csv("D:/IC Silwood/Project/R/cru_environmental_factors.csv")
environment<-environment[1,]
environment<-t(environment)
env_dist <- vegdist(environment, method = "euclidean")
partial_mantel_result <- mantel.partial(insect_dist, plant_dist, env_dist)
print(partial_mantel_result)


plant_partial_dist_vector <- as.vector(plant_dist[lower.tri(plant_dist)])
insect_partial_dist_vector <- as.vector(insect_dist[lower.tri(insect_dist)])
partial_mantel_plot_data <- data.frame(
  plant_dist = plant_partial_dist_vector,
  insect_dist = insect_partial_dist_vector
)

####################################################################
#################### Extraction of ################################
################ Environmental Factors #############################
####################################################################

library(R.utils)
library(raster)
library(ncdf4)
download.file("https://crudata.uea.ac.uk/cru/data/hrg/cru_ts_4.07/cruts.2304141047.v4.07/pre/cru_ts4.07.2021.2022.pre.dat.nc.gz",
              destfile = "cru_ts4.07.2021.2022.pre.dat.nc.gz")
gunzip("cru_ts4.07.2021.2022.pre.dat.nc.gz")
# Load precipitation data
pre <- brick("cru_ts4.07.2021.2022.pre.dat.nc", varname="pre")
mexico_area <- extent(-110,-70,10,30)
pre_mexico <- crop(pre, mexico_area)

coordinates <- read.csv("D:/IC Silwood/Project/R/coordinates.csv")
points <- data.frame(lon = coordinates$Lon, lat = coordinates$Lat)
rownames(points)<-coordinates$Trap
pre.sites <- data.frame(raster::extract(pre, points))
pre_2021 <- pre.sites[, 1:12]

colname_pre<-c("Jan","Feb","Mar","Apr","May","June","July","Aug","Sep","Oct","Nov","Dec")
colnames(pre_2021)<-colname_pre
rownames(pre_2021)<-coordinates$Trap

mantel_plot_data <- mantel_plot_data[complete.cases(mantel_plot_data), ]
partial_mantel_plot_data <- partial_mantel_plot_data[complete.cases(partial_mantel_plot_data), ]

library(cowplot)
plot1 <- ggplot(mantel_plot_data, aes(x = plant_dist, y = insect_dist)) +
  geom_point(color = "#1f78b4", alpha = 0.15) +
  geom_smooth(method = "lm", color = "#ff7f00", se = FALSE, size = 1) +  
  theme_classic() +
  labs(x = "Plant Community Dissimilarity",
       y = "Insect Community Dissimilarity",
       title = paste("Mantel Test: r =", round(mantel_result$statistic, 4), 
                     ", p =", mantel_result$signif)) +
  annotate("text", x = 0.9, y = 0.2, label = paste("r =", round(mantel_result$statistic, 4)), 
           size = 6, color = "black")+
  theme(plot.title = element_text(hjust = 0.5, face = "bold", color = "black",
        plot.tag = element_text(size = 35),
        axis.title = element_text(face = "bold", color = "black", size = 20),
        axis.text = element_text(color = "black",size = 17)))

plot1 <- ggplot(mantel_plot_data, aes(x = plant_dist, y = insect_dist)) +
  geom_point(color = "#1f78b4", alpha = 0.15) +
  geom_smooth(method = "lm", color = "#ff7f00", se = FALSE, size = 1) +  
  theme_classic() +
  labs(x = "Plant Community Dissimilarity",
       y = "Insect Community Dissimilarity",
       title = paste("Mantel Test: r =", round(mantel_result$statistic, 4), 
                     ", p =", mantel_result$signif)) +
  annotate("text", x = 0.9, y = 0.2, label = paste("r =", round(mantel_result$statistic, 4)), 
           size = 6, color = "black") +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", color = "black", size = 20),
        plot.tag = element_text(size = 35),
        axis.title = element_text(face = "bold", color = "black", size = 20),
        axis.text = element_text(color = "black", size = 17),
        axis.title.x = element_text(margin = margin(t = 10)),
        axis.title.y = element_text(margin = margin(r = 10)))

plot2 <- ggplot(partial_mantel_plot_data, aes(x = plant_dist, y = insect_dist)) +
  geom_point(color = "#33a02c", alpha = 0.15) +
  geom_smooth(method = "lm", color = "#ff7f00", se = FALSE, size = 1) +  
  theme_classic() +
  labs(x = "Plant Community Dissimilarity",
       y = "Insect Community Dissimilarity",
       title = paste("Partial Mantel Test: r =", round(partial_mantel_result$statistic, 4), 
                     ", p =", partial_mantel_result$signif)) +
  annotate("text", x = 0.9, y = 0.2, label = paste("r =", round(partial_mantel_result$statistic, 4)), 
           size = 6, color = "black") +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", color = "black", size = 20),  
        plot.tag = element_text(size = 35),
        axis.title = element_text(face = "bold", color = "black", size = 20),
        axis.text = element_text(color = "black", size = 17),
        axis.title.x = element_text(margin = margin(t = 10)),
        axis.title.y = element_text(margin = margin(r = 10)))

library(patchwork)
library(gridExtra)
library(cowplot)
plot1 <- plot1 + plot_annotation(tag_levels = 'A')
plot2 <- plot2 + plot_annotation(tag_levels = 'B')
mantel_test <- (plot1 | plot2) + 
  plot_annotation(tag_levels = 'A')+ 
  theme(plot.tag = element_text(size = 20))
print(mantel_test)