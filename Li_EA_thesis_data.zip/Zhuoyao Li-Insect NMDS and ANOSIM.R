################################################################################
######################## Huatulco insects NMDS#####################################
################################################################################

library(dplyr)
library(vegan)
library(ggplot2)
library(ggforce)

taxonomy_data_insect <- read.csv("D:/IC Silwood/Project/R/6-Insects_OTUs_Huatulco_Chamela_complete.csv")
taxonomy_data_insect <- taxonomy_data_insect %>%
  filter(Family != "Mantodea" & Family != "Odonata") %>%
  select(OTU, 12:230)  

taxonomy_data_insect[is.na(taxonomy_data_insect)] <- 0
rownames(taxonomy_data_insect)<-taxonomy_data_insect$OTU
taxonomy_data_insect$OTU<-NULL
taxonomy_data_insect <- as.data.frame(taxonomy_data_insect)
binary_data_insect <- taxonomy_data_insect %>%
  mutate(across(where(is.numeric), ~ ifelse(. > 0, 1, 0)))
binary_data_insect <- binary_data_insect[rowSums(binary_data_insect[, -1]) > 0, ]

huatulco_columns_insect <- grep("^Huat", colnames(binary_data_insect), value = TRUE)
huatulco_binary_data_insect <- binary_data_insect[, huatulco_columns_insect]
huatulco_binary_data_insect <- as.data.frame(huatulco_binary_data_insect)
binary_data_insect <- as.data.frame(lapply(binary_data_insect, function(x) as.numeric(as.character(x))))

print(dim(huatulco_binary_data_insect))
huatulco_binary_data_insect <- t(huatulco_binary_data_insect)

print(dim(huatulco_binary_data_insect))
print(head(huatulco_binary_data_insect))


dist_matrix_huatulco_insect <- vegdist(huatulco_binary_data_insect, method = "bray")
set.seed(27092000)
nmds_huatulco_insect <- metaMDS(dist_matrix_huatulco_insect, distance = "bray", k = 2, maxit = 999, trymax = 100, wascores = TRUE)
nmds_scores_huatulco_insect <- vegan::scores(nmds_huatulco_insect, display = "sites") %>% as.data.frame()
print(dim(nmds_scores_huatulco_insect))
nmds_scores_huatulco_insect$Sample <- rownames(nmds_scores_huatulco_insect)
colnames(nmds_scores_huatulco_insect)[1:2] <- c("NMDS1", "NMDS2")
nmds_scores_huatulco_insect$Group <- gsub(".*\\.(E\\d)$", "\\1", nmds_scores_huatulco_insect$Sample)
group_labels_huatulco <- c("E1" = "June", "E2" = "July", "E3" = "August", "E4" = "September", "E5" = "October", "E6" = "November", "E7" = "December")
table(nmds_scores_huatulco_insect$Group)


p3<-ggplot(nmds_scores_huatulco_insect, aes(x = NMDS1, y = NMDS2, color = Group)) +
  geom_point(size = 4) + 
  stat_ellipse(aes(fill = Group), geom = "polygon", alpha = 0.3, show.legend = FALSE) +  
  theme_classic() +  
  scale_color_manual(values = c("E1" = "#f57c6e", "E2" = "#84c3b7", "E3" = "#71b7ed", "E4" = "#b8aeeb", "E5" = "#956d6d", "E6" = "#f2a7da", "E7" = "#fae69e"),
                     labels = group_labels_huatulco) +  
  scale_fill_manual(values = c("E1" = "#f57c6e", "E2" = "#84c3b7", "E3" = "#71b7ed", "E4" = "#b8aeeb", "E5" = "#956d6d", "E6" = "#f2a7da", "E7" = "#fae69e"),
                    labels = group_labels_huatulco) +  
  labs(color = "Month", fill = "Month") +  
  theme(legend.position = "bottom", 
        axis.title = element_text(size = 20),  
        axis.text = element_text(size = 17),
        legend.text = element_text(size = 25),
        legend.title = element_text(size = 25),
        legend.key.width = unit(1.5, "cm"))+
  guides(color = guide_legend(override.aes = list(size = 7)),  
         fill = guide_legend(override.aes = list(size = 7))) +  
  theme(plot.tag = element_text(size = 35))

################################################################################
######################## Chamela insects NMDS#####################################
################################################################################

chamela_columns_insect <- grep("^Metacham", colnames(binary_data_insect), value = TRUE)
chamela_binary_data_insect <- binary_data_insect[, chamela_columns_insect]
chamela_binary_data_insect <- as.data.frame(chamela_binary_data_insect)
binary_data_insect <- as.data.frame(lapply(binary_data_insect, function(x) as.numeric(as.character(x))))
print(dim(chamela_binary_data_insect))
chamela_binary_data_insect <- t(chamela_binary_data_insect)
print(dim(chamela_binary_data_insect)) 
print(head(chamela_binary_data_insect)) 

dist_matrix_chamela_insect <- vegdist(chamela_binary_data_insect, method = "bray")
set.seed(27092000)
nmds_chamela_insect <- metaMDS(dist_matrix_chamela_insect, distance = "bray", k = 2, maxit = 999, trymax = 100, wascores = TRUE)
nmds_scores_chamela_insect <- vegan::scores(nmds_chamela_insect, display = "sites") %>% as.data.frame()
print(dim(nmds_scores_chamela_insect))
nmds_scores_chamela_insect$Sample <- rownames(nmds_scores_chamela_insect)
colnames(nmds_scores_chamela_insect)[1:2] <- c("NMDS1", "NMDS2")
nmds_scores_chamela_insect$Group <- gsub(".*\\.(E\\d)$", "\\1", nmds_scores_chamela_insect$Sample)
group_labels_chamela <- c("E1" = "May","E2" = "June", "E3" = "July", "E4" = "August", "E5" = "September", "E6" = "October")
table(nmds_scores_chamela_insect$Group)

p4<-ggplot(nmds_scores_chamela_insect, aes(x = NMDS1, y = NMDS2, color = Group)) +
  geom_point(size = 4) + 
  stat_ellipse(aes(fill = Group), geom = "polygon", alpha = 0.3, show.legend = FALSE) +  
  theme_classic() +  
  scale_color_manual(values = c("E1"="#f2b56f","E2" = "#f57c6e", "E3" = "#84c3b7", "E4" = "#71b7ed", "E5" = "#b8aeeb", "E6" = "#956d6d"),
                     labels = group_labels_chamela) +  
  scale_fill_manual(values = c("E1"="#f2b56f","E2" = "#f57c6e", "E3" = "#84c3b7", "E4" = "#71b7ed", "E5" = "#b8aeeb", "E6" = "#956d6d"),
                    labels = group_labels_chamela) +  
  labs(color = "Month", fill = "Month") +  
  theme(legend.position = "bottom",  
        axis.title = element_text(size = 20),  
        axis.text = element_text(size = 17),
        legend.text = element_text(size = 25),
        legend.title = element_text(size = 25),
        legend.key.width = unit(1.5, "cm"))+
  guides(color = guide_legend(override.aes = list(size = 7)), 
         fill = guide_legend(override.aes = list(size = 7))) + 
  theme(plot.tag = element_text(size = 35))

library(patchwork)
library(gridExtra)
library(cowplot)
p3 <- p3 + plot_annotation(tag_levels = 'A')
p4 <- p4 + plot_annotation(tag_levels = 'B')
Huatulco_Chamela_Insect_Community_Dissimilarity <- (p3 | p4) + 
  plot_annotation(tag_levels = 'A')+ 
  theme(plot.tag = element_text(size = 20))
print(Huatulco_Chamela_Insect_Community_Dissimilarity)

################################################################################
######################## Huatulco insects ANOSIM#####################################
################################################################################

month_mapping <- c(".E1" = "June", ".E2" = "July", ".E3" = "August", 
                   ".E4" = "September", ".E5" = "October", 
                   ".E6" = "November", ".E7" = "December")

for (suffix in names(month_mapping)) {
  rownames(huatulco_binary_data_insect) <- gsub(paste0(".*", suffix, "$"), month_mapping[suffix], rownames(huatulco_binary_data_insect))
}

print(rownames(huatulco_binary_data_insect))

anosim_month<-anosim(x=huatulco_binary_data_insect,grouping=rownames(huatulco_binary_data_insect))
anosim_month
plot(anosim_month)

distance_rank <- anosim_month$dis.rank
group_vector <- as.character(anosim_month$class.vec)
anosim_df <- data.frame(Distance = distance_rank, Group = group_vector)
anosim_df$Group <- factor(anosim_df$Group, levels = c("June", "July", "August", "September", "October", "November", "December", "Between"))

p3<-ggplot(anosim_df, aes(x = Group, y = Distance, fill = Group)) +
  geom_boxplot() +
  theme_minimal() +
  labs(x = "Month",
       y = "Ranked Distance") +
  scale_fill_manual(values = c("June" = "#FF6666", "July" = "#99FF99", "August" = "#99CCFF", "September" =  "#CC99FF", "October" = "#CD853F" , "November" = "#FF99CC", "December" ="#FFEE58","Between"="#B0B0B0")) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  

################################################################################
######################## Chamela insects ANOSIM#################################
################################################################################

month_mapping2 <- c(".E1" = "May", ".E2" = "June", ".E3" = "July", 
                    ".E4" = "August", ".E5" = "September", ".E6" = "October")

for (suffix in names(month_mapping2)) {
  rownames(chamela_binary_data_insect) <- gsub(paste0(".*", suffix, "$"), month_mapping2[suffix], rownames(chamela_binary_data_insect))
}

print(rownames(chamela_binary_data_insect))

anosim_month2<-anosim(x=chamela_binary_data_insect,grouping=rownames(chamela_binary_data_insect))
anosim_month2

distance_rank2 <- anosim_month2$dis.rank
group_vector2 <- as.character(anosim_month2$class.vec)
anosim_df2 <- data.frame(Distance = distance_rank2, Group = group_vector2)
anosim_df2$Group <- factor(anosim_df2$Group, levels = c("May", "June", "July", "August", "September", "October", "Between"))
p4<-ggplot(anosim_df2, aes(x = Group, y = Distance, fill = Group)) +
  geom_boxplot() +
  theme_minimal() +
  labs(x = "Month",
       y = "Ranked Distance") +
  scale_fill_manual(values = c("May" = "#FFB347", "June" = "#FF6666", "July" = "#99FF99", "August" = "#99CCFF", "September" =  "#CC99FF", "October" = "#CD853F", "Between"="#B0B0B0")) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  

library(patchwork)
library(gridExtra)
library(cowplot)

p3 <- p3 + plot_annotation(tag_levels = 'A')
p4 <- p4 + plot_annotation(tag_levels = 'B')

Huatulco_Chamela_Insect_Community_ANOSIM <- (p3 | p4) + plot_annotation(tag_levels = 'A')
print(Huatulco_Chamela_Insect_Community_ANOSIM)
