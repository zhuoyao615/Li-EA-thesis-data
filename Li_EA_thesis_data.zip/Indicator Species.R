rm(list=ls())

library(dplyr)
library(ggplot2)
library(scales)
library(lme4)

setwd("D:/IC Silwood/Project/R")
getwd()

pre<-read.csv("D:/IC Silwood/Project/R/cru_environmental_factors.csv")
pre<-pre[1, ]
pre<-t(pre)
colnames(pre)[colnames(pre) == "1"] <- "Precipitation"

plant<-read.csv("D:/IC Silwood/Project/R/plant_OTU_sample_taxonomy.csv")
plant <- plant %>%
  select(OTU, 26:243) 
plant <- plant[c(1,2,3,20), ]
rownames(plant)<-plant$OTU
plant$OTU<-NULL
plant <- t(plant)

plant <- as.data.frame(plant)
pre <- as.data.frame(pre)
plant$RowNames <- rownames(plant)
pre$RowNames <- rownames(pre)

plant_pre <- left_join(plant, pre, by = "RowNames")
rownames(plant_pre) <- plant_pre$RowNames
plant_pre <- plant_pre[, -which(names(plant_pre) == "RowNames")]

###############################################################################
############################### Huatulco #####################################
###############################################################################

huatulco_plant_pre<-plant_pre[1:98, ]
huatulco_plant_pre<-as.data.frame(huatulco_plant_pre)
huatulco_plant_pre$Plot <- substr(rownames(huatulco_plant_pre), 1, nchar(rownames(huatulco_plant_pre)) - 3)

huatulco_plant_pre$log_otu2 <- log(huatulco_plant_pre$otu2 + 1)

model1<-lmer(log_otu2 ~ Precipitation + (1|Plot), data = huatulco_plant_pre)
summary(model1)

p1 <-ggplot(huatulco_plant_pre, aes(x = Precipitation, y = log_otu2)) +
  geom_point(size = 4, alpha = 0.6, color = "blue") +  
  labs(x = "Precipitation (mm)", 
       y = "Log (Ceiba Abundance + 1)") + 
  theme_minimal() +  
  theme(text = element_text(size = 20),  
        axis.title = element_text(face = "bold"))  
print(p1)

huatulco_plant_pre$log_otu20 <- log(huatulco_plant_pre$otu20 + 1)
model2<-lmer(log_otu20 ~ Precipitation + (1|Plot), data = huatulco_plant_pre)
summary(model2)

p2 <-ggplot(huatulco_plant_pre, aes(x = Precipitation, y = log_otu20)) +
  geom_point(size = 4, alpha = 0.6, color = "purple") +  
  geom_smooth(method = "lm", se = TRUE, color = "red", fill = "lightpink", level = 0.95) +  
  labs(x = "Precipitation (mm)", 
       y = "Log (OTU20 Abundance + 1)") +  
  theme_minimal() + 
  theme(text = element_text(size = 20),  
        axis.title = element_text(face = "bold"))  
print(p2)

library(patchwork)
library(gridExtra)
library(cowplot)
p1 <- p1 + plot_annotation(tag_levels = 'A')
p2 <- p2 + plot_annotation(tag_levels = 'B')
lm <- (p1 | p2) + plot_annotation(tag_levels = 'A')
print(lm)

###############################################################################
############################### Chamela #####################################
###############################################################################

chamela_plant_pre<-plant_pre[99:218, ]
chamela_plant_pre<-as.data.frame(chamela_plant_pre)
chamela_plant_pre$Plot <- substr(rownames(chamela_plant_pre), 1, nchar(rownames(chamela_plant_pre)) - 3)

chamela_plant_pre$log_otu3 <- log(chamela_plant_pre$otu3 + 1)
model3<-lm(log_otu3 ~ Precipitation, data = chamela_plant_pre)
summary(model3)

p3 <-ggplot(chamela_plant_pre, aes(x = Precipitation, y = log_otu3)) +
  geom_point(size = 4, alpha = 0.6, color = "blue") + 
  geom_smooth(method = "lm", se = TRUE, color = "red", fill = "lightpink", level = 0.95) +  
  labs(x = "Precipitation (mm)", 
       y = "Log (Zinnia maritima Abundance + 1)") +  
  theme_minimal() +  
  theme(text = element_text(size = 20),  
        axis.title = element_text(face = "bold")) 
print(p3)

chamela_plant_pre$log_otu1 <- log(chamela_plant_pre$otu1 + 1)

model4<-lm(log_otu1 ~ Precipitation, data = chamela_plant_pre)
summary(model4)

p4 <-ggplot(chamela_plant_pre, aes(x = Precipitation, y = log_otu1)) +
  geom_point(size = 4, alpha = 0.6, color = "purple") + 
  geom_smooth(method = "lm", se = TRUE, color = "red", fill = "lightpink", level = 0.95) +  
  labs(x = "Precipitation (mm)", 
       y = "Log (OTU1 Abundance + 1)") + 
  theme_minimal() +  
  theme(text = element_text(size = 20), 
        axis.title = element_text(face = "bold")) 
print(p4)

library(patchwork)
library(gridExtra)
library(cowplot)

p1 <- p1 + plot_annotation(tag_levels = 'A')
p2 <- p2 + plot_annotation(tag_levels = 'B')
p3 <- p3 + plot_annotation(tag_levels = 'C')
p4 <- p4 + plot_annotation(tag_levels = 'D')

indicator_species <- (p1 | p2)  / (p3 | p4) + plot_annotation(tag_levels = 'A')&
  theme(plot.tag = element_text(size = 35))
print(indicator_species)