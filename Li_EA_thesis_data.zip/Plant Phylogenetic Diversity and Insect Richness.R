rm(list=ls())

setwd("D:/IC Silwood/Project/R/")

library(dplyr)

pd_values<-read.csv("D:/IC Silwood/Project/R/Phylogenetic Diversity_Mexico.csv")
insect<-read.csv("D:/IC Silwood/Project/R/6-Insects_OTUs_Huatulco_Chamela_complete.csv")
insect <- insect %>%
  filter(Family != "Mantodea" & Family != "Odonata") %>%
  select(12:230)

insect <- insect %>%
  mutate(across(where(is.numeric), ~ ifelse(. > 0, 1, 0)))
rownames(insect) <- insect$OTU
insect$OTU<-NULL

richness <- colSums(insect == 1)
richness_df <- data.frame(Sample = names(richness), Richness = richness)
print(head(richness_df))
write.csv(richness_df, "D:/IC Silwood/Project/R/insect richness.csv", row.names = FALSE)

insect_richness<- read.csv("D:/IC Silwood/Project/R/insect richness.csv")
pd_insect <- merge(pd_values, insect_richness, by.x = "X", by.y = "Sample")

colnames(pd_insect)[colnames(pd_insect) == "Richness"] <- "Insect Richness"
pd_insect$Plot <- substr(pd_insect$X, 1, nchar(pd_insect$X) - 3)

library(lme4)

pd_insect$PD_standard <- scale(pd_insect$PD.x)
model <- lmer( PD ~  `Insect Richness` + (1 | Plot), data = pd_insect)
summary(model)
aic_value <- AIC(model)
print(aic_value)

model2 <- lm( PD ~  `Insect Richness`, data = pd_insect)
summary(model2)
aic_value2 <- AIC(model2)
print(aic_value2)
