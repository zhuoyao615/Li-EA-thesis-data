#############################################################
############### Huatulco Plant NMDS analysis#################
#############################################################

library(vegan)
library(ggplot2)
library(ggforce)
library(dplyr)

taxonomy_data <- read.csv("D:/IC Silwood/Project/R/plant_OTU_sample_taxonomy.csv")
taxonomy_data <- taxonomy_data %>%
  filter(kingdom != "Fungi" & kingdom != "Bacteria")%>%
  select(OTU, 26:243) 
taxonomy_data <- as.data.frame(taxonomy_data)
rownames(taxonomy_data)<-taxonomy_data$OTU
taxonomy_data$OTU<-NULL
binary_data <- taxonomy_data %>%
  mutate(across(where(is.numeric), ~ ifelse(. > 0, 1, 0)))

huatulco_columns <- grep("^Huat", colnames(binary_data), value = TRUE)
huatulco_binary_data <- binary_data[, huatulco_columns]
huatulco_binary_data <- as.data.frame(huatulco_binary_data)
print(dim(huatulco_binary_data))
huatulco_binary_data <- t(huatulco_binary_data)

print(dim(huatulco_binary_data)) 
print(head(huatulco_binary_data)) 

dist_matrix_huatulco <- vegdist(huatulco_binary_data, method = "bray")
set.seed(27092000)
nmds_huatulco <- metaMDS(dist_matrix_huatulco, distance = "bray", k = 2, maxit = 999, trymax = 100, wascores = TRUE)
nmds_scores_huatulco <- vegan::scores(nmds_huatulco, display = "sites") %>% as.data.frame()
print(dim(nmds_scores_huatulco))
nmds_scores_huatulco$Sample <- rownames(nmds_scores_huatulco)
colnames(nmds_scores_huatulco)[1:2] <- c("NMDS1", "NMDS2")
nmds_scores_huatulco$Group <- gsub(".*\\.(E\\d)$", "\\1", nmds_scores_huatulco$Sample)
group_labels_huatulco <- c("E1" = "June", "E2" = "July", "E3" = "August", "E4" = "September", "E5" = "October", "E6" = "November", "E7" = "December")
table(nmds_scores_huatulco$Group)

p1<-ggplot(nmds_scores_huatulco, aes(x = NMDS1, y = NMDS2, color = Group)) +
  geom_point(size = 4) +  
  stat_ellipse(aes(fill = Group), geom = "polygon", alpha = 0.3, show.legend = FALSE) +  # 绘制95%置信椭圆
  theme_classic() +  
  scale_color_manual(values = c("E1" = "#f57c6e", "E2" = "#84c3b7", "E3" = "#71b7ed", "E4" = "#b8aeeb", "E5" = "#956d6d", "E6" = "#f2a7da", "E7" = "#fae69e"),
                     labels = group_labels_huatulco) + 
  scale_fill_manual(values = c("E1" = "#f57c6e", "E2" = "#84c3b7", "E3" = "#71b7ed", "E4" = "#b8aeeb", "E5" = "#956d6d", "E6" = "#f2a7da", "E7" = "#fae69e"),
                    labels = group_labels_huatulco) +  
  labs(color = "Month", fill = "Month") +  
  theme(legend.position = "bottom", 
        axis.title = element_text(size = 20),  
        axis.text = element_text(size = 17),
        legend.text = element_text(size = 25),
        legend.title = element_text(size = 25),
        legend.key.width = unit(1.5, "cm"))+
  guides(color = guide_legend(override.aes = list(size = 7)),  
         fill = guide_legend(override.aes = list(size = 7))) +  
  theme(plot.tag = element_text(size = 35)) 

nmds_scores_huatulco$group <- ifelse(grepl("^Huat", nmds_scores_huatulco$Sample), "huatulco", "chamela")

#############################################################
############### Chamela Plant NMDS analysis#################
#############################################################

chamela_columns <- grep("^Metacham", colnames(binary_data), value = TRUE)
chamela_binary_data <- binary_data[, chamela_columns]
chamela_binary_data <- as.data.frame(chamela_binary_data)
print(dim(chamela_binary_data))
chamela_binary_data <- t(chamela_binary_data)

print(dim(chamela_binary_data)) 
print(head(chamela_binary_data)) 

dist_matrix_chamela <- vegdist(chamela_binary_data, method = "bray")
set.seed(27092000)
nmds_chamela <- metaMDS(dist_matrix_chamela, distance = "bray", k = 2, maxit = 999, trymax = 100, wascores = TRUE)
nmds_scores_chamela <- vegan::scores(nmds_chamela, display = "sites") %>% as.data.frame()
print(dim(nmds_scores_chamela))
nmds_scores_chamela$Sample <- rownames(nmds_scores_chamela)
colnames(nmds_scores_chamela)[1:2] <- c("NMDS1", "NMDS2")
nmds_scores_chamela$Group <- gsub(".*\\.(E\\d)$", "\\1", nmds_scores_chamela$Sample)
group_labels_chamela <- c("E1" = "May", "E2" = "June", "E3" = "July", "E4" = "August", "E5" = "September", "E6" = "October")
table(nmds_scores_chamela$Group)

p2<-ggplot(nmds_scores_chamela, aes(x = NMDS1, y = NMDS2, color = Group)) +
  geom_point(size = 4) + 
  stat_ellipse(aes(fill = Group), geom = "polygon", alpha = 0.3, show.legend = FALSE) + 
  theme_classic() +  
  scale_color_manual(values = c("E1"="#f2b56f","E2" = "#f57c6e", "E3" = "#84c3b7", "E4" = "#71b7ed", "E5" = "#b8aeeb", "E6" = "#956d6d"),
                     labels = group_labels_chamela) + 
  scale_fill_manual(values = c("E1"="#f2b56f","E2" = "#f57c6e", "E3" = "#84c3b7", "E4" = "#71b7ed", "E5" = "#b8aeeb", "E6" = "#956d6d"),
                    labels = group_labels_chamela) +  
  labs(color = "Month", fill = "Month") +  
  theme(legend.position = "bottom",  
        axis.title = element_text(size = 20),  
        axis.text = element_text(size = 17),
        legend.text = element_text(size = 25),
        legend.title = element_text(size = 25),
        legend.key.width = unit(1.5, "cm"))+
  guides(color = guide_legend(override.aes = list(size = 7)),  
         fill = guide_legend(override.aes = list(size = 7))) +  
  theme(plot.tag = element_text(size = 35)) 

nmds_scores_huatulco$group <- ifelse(grepl("^Huat", nmds_scores_huatulco$Sample), "huatulco", "chamela")

library(patchwork)
library(gridExtra)
library(cowplot)
p1 <- p1 + plot_annotation(tag_levels = 'A')
p2 <- p2 + plot_annotation(tag_levels = 'B')

Huatulco_Chamela_Plant_Community_Dissimilarity <- (p1 | p2) + 
  plot_annotation(tag_levels = 'A') + 
  theme(plot.tag = element_text(size = 35))
print(Huatulco_Chamela_Plant_Community_Dissimilarity)

#############################################################
############### Huatulco Plant ANOSIM analysis###############
#############################################################

month_mapping <- c(".E1" = "June", ".E2" = "July", ".E3" = "August", 
                   ".E4" = "September", ".E5" = "October", 
                   ".E6" = "November", ".E7" = "December")

for (suffix in names(month_mapping)) {
  rownames(huatulco_binary_data) <- gsub(paste0(".*", suffix, "$"), month_mapping[suffix], rownames(huatulco_binary_data))
}

print(rownames(huatulco_binary_data))

anosim_month<-anosim(x=huatulco_binary_data,grouping=rownames(huatulco_binary_data))
anosim_month

distance_rank <- anosim_month$dis.rank
group_vector <- as.character(anosim_month$class.vec)
anosim_df <- data.frame(Distance = distance_rank, Group = group_vector)
anosim_df$Group <- factor(anosim_df$Group, levels = c("June", "July", "August", "September", "October", "November", "December", "Between"))

p3<-ggplot(anosim_df, aes(x = Group, y = Distance, fill = Group)) +
  geom_boxplot() +
  theme_minimal() +
  labs(x = "Month",
       y = "Ranked Distance") +
  scale_fill_manual(values = c("June" = "#FF6666", "July" = "#99FF99", "August" = "#99CCFF", "September" =  "#CC99FF", "October" = "#CD853F" , "November" = "#FF99CC", "December" ="#FFEE58","Between"="#B0B0B0")) +

#############################################################
############### Chamela Plant ANOSIM analysis################
#############################################################

month_mapping2 <- c(".E1" = "May", ".E2" = "June", ".E3" = "July", 
                    ".E4" = "August", ".E5" = "September", ".E6" = "October")

for (suffix in names(month_mapping2)) {
  rownames(chamela_binary_data) <- gsub(paste0(".*", suffix, "$"), month_mapping2[suffix], rownames(chamela_binary_data))
}

print(rownames(chamela_binary_data))

anosim_month2<-anosim(x=chamela_binary_data,grouping=rownames(chamela_binary_data))
anosim_month2

distance_rank2 <- anosim_month2$dis.rank
group_vector2 <- as.character(anosim_month2$class.vec)
anosim_df2 <- data.frame(Distance = distance_rank2, Group = group_vector2)
anosim_df2$Group <- factor(anosim_df2$Group, levels = c("May", "June", "July", "August", "September", "October", "Between"))

p4<-ggplot(anosim_df2, aes(x = Group, y = Distance, fill = Group)) +
  geom_boxplot() +
  theme_minimal() +
  labs(x = "Month",
       y = "Ranked Distance") +
  scale_fill_manual(values = c("May" = "#FFB347", "June" = "#FF6666", "July" = "#99FF99", "August" = "#99CCFF", "September" =  "#CC99FF", "October" = "#CD853F", "Between"="#B0B0B0")) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

library(patchwork)
library(gridExtra)
library(cowplot)
p3 <- p3 + plot_annotation(tag_levels = 'A')
p4 <- p4 + plot_annotation(tag_levels = 'B')

Huatulco_Chamela_Plant_Community_ANOSIM <- (p3 | p4) + plot_annotation(tag_levels = 'A')
print(Huatulco_Chamela_Plant_Community_ANOSIM)
